/* Modify this object to add new events to your page
*  Example object:
    {
        "name": "Sample Event",
        "dateString": "27th of July 2024",
        "description": "Some HTML event description here Some HTML event description here Some HTML event description here Some HTML event description here",
        "src": "images/placeholder.jpeg"
    }
* */
const EVENT_DATA = [
    {
        "name": "Sample Event",
        "dateString": "27th of July 2024",
        "description": "Some HTML event description here Some HTML event description here Some HTML event description here Some HTML event description here",
        "src": "images/placeholder.jpeg"
    }
];